import torch
import torch.nn as nn

import torch.nn.functional as F
class MINEEstimator(nn.Module):
    def __init__(self, size1, size2):
        super(MINEEstimator, self).__init__()

        # Vanilla MLP for mutual information estimation
        self.net = nn.Sequential(
            nn.Linear(size1 + size2, size1 // 2),
            nn.BatchNorm1d(size1 // 2),
            nn.ReLU(True),
            nn.Linear(size1 // 2, size1 // 2),
            nn.BatchNorm1d(size1 // 2),
            nn.ReLU(True),
            nn.Linear(size1 // 2, 1),  # Output is a scalar value
        )

    def forward(self, x1, x2):
        # Positive samples
        pos = self.net(torch.cat([x1, x2], 1))

        # Negative samples (by shifting x1)
        temp = torch.roll(x1, 1, 0)  # Roll x1 by 1 to create a negative sample
        neg = self.net(torch.cat([temp, x2], 1))

        # MINE loss (maximize MI)
        return -F.softplus(-pos).mean() - F.softplus(neg).mean()
