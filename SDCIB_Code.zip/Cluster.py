import numpy as np
from scipy.optimize import linear_sum_assignment


def compute_cost_matrix(probabilities_view1, probabilities_view2):
    num_clusters_view1 = probabilities_view1.shape[1]
    num_clusters_view2 = probabilities_view2.shape[1]

    cost_matrix = np.zeros((num_clusters_view1, num_clusters_view2))

    for i in range(num_clusters_view1):
        for j in range(num_clusters_view2):
            cost_matrix[i, j] = -np.sum((np.argmax(probabilities_view1, axis=1) == i) &
                                        (np.argmax(probabilities_view2, axis=1) == j))

    return cost_matrix


def match_cluster_probabilities(probabilities_list):
    num_views = len(probabilities_list)
    final_probabilities = []

    final_probabilities.append(probabilities_list[0])
    for i in range(1, num_views):
        cost_matrix = compute_cost_matrix(probabilities_list[i - 1], probabilities_list[i])
        row_ind, col_ind = linear_sum_assignment(cost_matrix)
        matched_probabilities = np.zeros_like(probabilities_list[i])
        for row, col in zip(row_ind, col_ind):
            matched_probabilities[:, col] += probabilities_list[i][:, row]
        final_probabilities.append(matched_probabilities)

    return final_probabilities




def getCluster(all_probabilities):
    aligned_probabilities = match_cluster_probabilities(all_probabilities)
    pre_label = np.sum(aligned_probabilities, axis=0)
    pre_label = np.argmax(pre_label, axis=1)
    return pre_label

