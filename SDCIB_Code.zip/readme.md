# Super Deep Contrastive Information Bottleneck for Multi-modal Clustering

We have built new state-of-the-art performance on several benchmarked datasets.

> Abstract: In an era of increasingly diverse information sources, multi-modal clustering (MMC) has become a key technology for processing multi-modal data. It can apply and integrate the feature information and potential relationships of different modalities. Although there is a wealth of research on MMC, due to the complexity of datasets, a major challenge remains in how to deeply explore the complex latent information and interdependencies between modalities. To address this issue, this paper proposes a method called super deep contrastive information bottleneck (SDCIB) for MMC, which aims to explore and utilize all types of latent information to the fullest extent. Specifically, the proposed SDCIB explicitly introduces the rich information contained in the encoder's hidden layers into the loss function for the first time, thoroughly mining both modal features and the hidden relationships between modalities. Moreover, the proposed SDCIB performs dual optimization by simultaneously considering consistency information from both the feature distribution and clustering assignment perspectives, the proposed SDCIB significantly improves clustering accuracy and robustness. We conducted experiments on 4 multi-modal datasets and the accuracy of the method on the ESP dataset improved by 9.3%. The results demonstrate the superiority and clever design of the proposed SDCIB. The source code is available on https://github.com/ShizheHu.

**If you found this code helps your work, do not hesitate to cite my paper or star this repo!**

## Installation
Requires Python >= 3.9 (tested on 3.9)

To install the required packages, run:
```
pip install -r requirements.txt
```



## Running an experiment
In the `SDCIB` directory, run:
```
python train.py --data_name <dataset>
```
where `<dataset>` is the name of a dataset in `Dataset/`.

For example:
```
python train.py --data_name esp
```

### Other adjustable parameters:

- --runs: The total number of times the program has been run. (Default: 10)
- --epochs: Number of epochs for training. (Default: 40)
- --alpha: Weight Parameters. (Select from [0.1, 0.2, 0.4, 0.6, 0.8], default is 0.1)
- --beta: Weight Parameters. (Select from [1, 10, 100, 1000, 10000], default is 1)
- --batch_size: Batch sample size. (Default: 32)