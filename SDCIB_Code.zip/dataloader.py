import numpy as np
from torch.utils.data import Dataset
import torch

class DatasetNpz(Dataset):
    def __init__(self, name):
        data = np.load('Dataset/' + f"{name}.npz")
        self.n_views = int(data["n_views"])
        self.labels = data["labels"].reshape(-1, 1)
        # self.labels = data["labels"]
        self.n_clusters = len(np.unique(self.labels))
        self.data_views = []
        self.view_dims = []

        for v in range(self.n_views):
            data_view = data[f"view_{v}"].astype(np.float32)
            self.data_views.append(data_view)
            self.view_dims.append(data_view.shape[1])
        self.data_size = self.data_views[0].shape[0]

    def __len__(self):
        return self.data_size

    def __getitem__(self, idx):
        return [torch.from_numpy(view[idx]) for view in self.data_views], \
            torch.from_numpy(self.labels[idx]), \
            torch.from_numpy(np.array(idx)).long()



def load_data(dataset):
    dataset = DatasetNpz(dataset)
    dims = dataset.view_dims
    view = dataset.n_views
    class_num = dataset.n_clusters
    data_size = dataset.data_size

    return dataset, dims, view, class_num, data_size
