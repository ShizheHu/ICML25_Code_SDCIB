
import torch.nn as nn
from torch.nn.functional import softplus
from torch.distributions import Normal, Independent


class Model_view(nn.Module):
    def __init__(self, cluster_num, dim_in, dim_out):
        super(Model_view, self).__init__()
        self.layer_num = 4
        self.name = 'Model_1'
        self.cluster = nn.Sequential(
            nn.Linear(dim_out, cluster_num),
            nn.Softmax(dim=1)
        )

        self.net = nn.Sequential(
            nn.Linear(dim_in, 1024),
            nn.BatchNorm1d(1024),
            nn.ReLU(),
            nn.Linear(1024, 1024),
            nn.BatchNorm1d(1024),
            nn.ReLU(),
            nn.Linear(1024, 1024),
            nn.BatchNorm1d(1024),
            nn.ReLU(),
            nn.Linear(1024, dim_out),
            nn.BatchNorm1d(dim_out),
            nn.ReLU(),
        )

        self.fc_1 = nn.Sequential(
            nn.Linear(1024, 2048),
            nn.BatchNorm1d(2048),
            nn.ReLU(),
        )

        self.fc_2 = nn.Sequential(
            nn.Linear(1024, 2048),
            nn.BatchNorm1d(2048),
            nn.ReLU(),
        )

        self.fc_3 = nn.Sequential(
            nn.Linear(1024, 2048),
            nn.BatchNorm1d(2048),
            nn.ReLU(),
        )

        self.fc_4 = nn.Sequential(
            nn.Linear(dim_out, dim_out*2),
            nn.BatchNorm1d(dim_out*2),
            nn.ReLU(),
        )

    def getDistribution(self, index, h_feature):
        if index == 0:
            params = self.fc_1(h_feature)
            feature_dim = 1024
        if index == 1:
            params = self.fc_2(h_feature)
            feature_dim = 1024
        if index == 2:
            params = self.fc_3(h_feature)
            feature_dim = 1024
        if index == 3:
            params = self.fc_4(h_feature)
            feature_dim = 128
        mu, sigma = params[:, :feature_dim], params[:, feature_dim:]
        sigma = softplus(sigma) + 1e-7  # Make sigma always positive
        h_distribution = Independent(Normal(loc=mu, scale=sigma), 1)
        h_feature = h_distribution.rsample()
        return h_feature, h_distribution



    def forward(self, input):
        h_features = {}
        h_distributions = {}
        x = input
        for index in range(self.layer_num):
            x = self.net[(index) * 3](x)
            x = self.net[(index) * 3 + 1](x)
            x = self.net[(index) * 3 + 2](x)
            h_features[index], h_distributions[index] = self.getDistribution(index, x)
        h_cluster = self.cluster(h_features[self.layer_num-1])
        return h_features, h_cluster, h_distributions

