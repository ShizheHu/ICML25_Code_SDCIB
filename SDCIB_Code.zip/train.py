from dataloader import load_data
import argparse
import torch
import numpy as np
import utils1
from network import Model_view
from itertools import chain as ichain
import torch.distributions.normal as normal
from tqdm import trange
from Cluster import getCluster
from Loss import InstanceLoss, ClusterLoss, getMILoss
from MIEstimator import MINEEstimator

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

DataName = "esp"
parser = argparse.ArgumentParser()
parser.add_argument('--data_name', default=DataName)
parser.add_argument('--batch_size', default=32, type=int)
parser.add_argument("--instance_temperature", default=0.1, type=float)
parser.add_argument("--cluster_temperature", default=0.1, type=float)
parser.add_argument("--instance_hyper_parameters", default=1.0, type=float)
parser.add_argument("--cluster_hyper_parameters", default=1.0, type=float)
parser.add_argument("--learning_rate", default=0.0001, type=float)
parser.add_argument("--runs", default=10, type=int)
parser.add_argument("--epochs", default=40, type=int)
parser.add_argument('--seed', default=0, type=int)
parser.add_argument('--feature_dim', default=128, type=int)
parser.add_argument('--layer_num', default=4, type=int)
parser.add_argument('--beta', default=1, type=float)
parser.add_argument('--alpha', default=0.1, type=float)
parser.add_argument('--layers', default=[1024, 1024, 1024, 128], type=list)
args = parser.parse_args()


def run():
    dataset, view_dims, n_views, n_clusters, data_size = load_data(args.data_name)

    train_loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True,
        drop_last=True
    )

    set_seed(args.seed)
    accs = []
    nmis = []

    # start run for
    for run in range(args.runs):
        print(f"ROUND:{run + 1}")

        min_loss = float('inf')
        instance_loss = InstanceLoss(args.batch_size, n_clusters, args.instance_temperature, device)
        cluster_loss = ClusterLoss(n_clusters, args.cluster_temperature, device)
        max_Acc = 0
        max_NMI = 0
        models = {}
        data_views = {}
        priors = {}
        estimator_mi_hc = []

        for k in range(args.layer_num):
            prior_loc = torch.zeros(args.batch_size, args.layers[k]).to(device)
            prior_scale = torch.ones(args.batch_size, args.layers[k]).to(device)
            priors[k] = normal.Normal(prior_loc, prior_scale)
        for i in range(n_views):
            models[i] = Model_view(n_clusters, dataset.view_dims[i], args.feature_dim).to(device)
            data_views[i] = torch.from_numpy(dataset.data_views[i]).to(device)
            estimator_mi_hc.append({})
            for k in range(args.layer_num):
                estimator_mi_hc[i][k] = MINEEstimator(args.layers[k], n_clusters).to(device)

        ge_chain1 = ichain(*[list(models[i].parameters()) for i in range(len(models))])
        ge_chain2 = ichain(*[list(estimator_mi_hc[i][k].parameters())
                    for i in range(len(models)) for k in range(args.layer_num)])
        optimiser1 = torch.optim.Adam(ge_chain1, lr=args.learning_rate)
        optimiser2 = torch.optim.Adam(ge_chain2, lr=args.learning_rate)

        for epoch in trange(args.epochs):
            features = {}
            clusters = {}
            h_distributions = {}
            epoch_loss = 0
            for batch, (data, _, _) in enumerate(train_loader):
                loss = 0
                for v in range(n_views):
                    data[v] = data[v].to(device)
                    features[v], clusters[v], h_distributions[v] = models[v](data[v])

                if epoch_loss == 0:
                    for e in range(100):
                        mi_hc = 0
                        for v in range(n_views):
                            for k in range(args.layer_num):
                                feature_detached = features[v][k].detach()
                                cluster_detached = clusters[v].detach()
                                mi_hc += estimator_mi_hc[v][k](feature_detached, cluster_detached)
                        optimiser2.zero_grad()
                        mi_hc.backward()
                        optimiser2.step()



                for i in range(n_views):
                    loss1 = 0
                    loss2 = 0
                    for k in range(args.layer_num):
                        loss1_1, loss2_1 = getMILoss(h_distributions[i][k], clusters[i], priors[k], estimator_mi_hc[i][k], device)
                        loss1 += loss1_1
                        loss2 += loss2_1
                    loss3 = 0
                    loss4 = 0
                    for j in range(n_views):
                        if i != j:
                            for k in range(args.layer_num):
                                loss3 += instance_loss(features[i][k], features[j][k])
                            loss4 += cluster_loss(clusters[i], clusters[j])
                    loss += args.alpha * (loss1 + args.beta * loss2) + (1 - args.alpha) * (loss3 + loss4)

                optimiser1.zero_grad()
                optimiser2.zero_grad()
                loss.backward()
                optimiser1.step()
                optimiser2.step()

                epoch_loss += loss.item()

            print("epoch_loss: %d" % loss)
            Acc, NMI = getACC_NMI(models, data_views, dataset.labels, n_views)
            print("ACC: %.4f NMI: %.4f ***" % (Acc, NMI))
            if loss < min_loss:
                min_loss = loss
                max_Acc = Acc
                max_NMI = NMI
        accs.append(max_Acc)
        nmis.append(max_NMI)
    return np.max(accs), np.max(nmis)

def set_seed(seed):
    print("seed is {}".format(seed))
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True


def getACC_NMI(models, data_views, label, view_num):
    label = label.flatten()
    all_probabilities = []
    for i in range(view_num):
        _, x_out, _ = models[i](data_views[i])
        all_probabilities.append(x_out.cpu().detach().numpy())
        cluster_i = np.argmax(all_probabilities[i], axis=1)
        acc_i = utils1.metrics.acc(cluster_i, label)
        nmi_i = utils1.metrics.nmi(cluster_i, label)
        print("ACC%d: %.4f NMI%d: %.4f ***" % (i, acc_i, i, nmi_i))
    pre_label = getCluster(all_probabilities)

    acc1 = utils1.metrics.acc(pre_label, label)
    nmi1 = utils1.metrics.nmi(pre_label, label)
    return acc1, nmi1


if __name__ == '__main__':
    accs, nmis = run()
    maxAcc = np.max(accs)
    maxNMI = np.max(nmis)
    print("maxAcc=%.4f, maxNMI=%.4f" % (maxAcc, maxNMI))


