import torch
import torch.nn as nn
from torch.distributions import kl_divergence
import torch.nn.functional as F


class InstanceLoss(nn.Module):
    def __init__(self, batch_size, n_clusters, temperature, device):
        super(InstanceLoss, self).__init__()
        self.batch_size = batch_size
        self.n_clusters = n_clusters
        self.device = device
        self.temperature = temperature
        self.mask = self.mask_correlated_samples(batch_size)
        self.negative_samples_ratio = 0.5
        self.criterion = nn.CrossEntropyLoss(reduction="mean")

    def _get_negative(self, final_pred):
        pos_idx = torch.arange(0, 2 * self.batch_size).long()

        pseudo_label = final_pred.detach().argmax(dim=1)
        pseudo_label = torch.cat(2 * [pseudo_label], dim=0)

        eye = torch.eye(self.n_clusters, device=self.device)
        weights = (1 - eye[pseudo_label])[:, pseudo_label[pos_idx]].T
        n_negative = int(self.negative_samples_ratio * pseudo_label.size(0))
        neg_idx = torch.topk(weights, n_negative, dim=1, largest=True, sorted=False).indices

        return pos_idx, neg_idx

    def mask_correlated_samples(self, batch_size):
        N = 2 * batch_size
        mask = torch.ones((N, N))
        mask.fill_diagonal_(0)
        for i in range(batch_size):
            mask[i, batch_size + i] = 0
            mask[batch_size + i, i] = 0
        return mask.bool()

    def forward(self, z_i, z_j, final_pred=None):
        N = 2 * self.batch_size
        z = torch.cat((z_i, z_j), dim=0)
        z = F.normalize(z, dim=1)

        sim = torch.matmul(z, z.T) / self.temperature
        sim_i_j = torch.diag(sim, self.batch_size)
        sim_j_i = torch.diag(sim, -self.batch_size)

        positive_samples = torch.cat((sim_i_j, sim_j_i), dim=0).reshape(N, 1)
        if final_pred is None:
            negative_samples = sim[self.mask].reshape(N, -1)
        else:
            pos_idx, neg_idx = self._get_negative(final_pred)
            negative_samples = sim[pos_idx.unsqueeze(1), neg_idx].reshape(N, -1)

        labels = torch.zeros(N).to(self.device).long()
        logits = torch.cat((positive_samples, negative_samples), dim=1)
        loss = self.criterion(logits, labels)

        return loss - torch.log(torch.tensor(self.batch_size).float())


class ClusterLoss(nn.Module):
    def __init__(self, class_num, temperature, device):
        super(ClusterLoss, self).__init__()
        self.class_num = class_num
        self.device = device
        self.temperature = temperature
        self.mask = self.mask_correlated_clusters()
        self.criterion = nn.CrossEntropyLoss(reduction="mean")
        self.similarity_f = nn.CosineSimilarity(dim=2)
        self.epsilon = 1e-8

    def mask_correlated_clusters(self):
        N = 2 * self.class_num
        mask = torch.ones((N, N), device=self.device)
        mask.fill_diagonal_(0)
        for i in range(self.class_num):
            mask[i, self.class_num + i] = 0
            mask[self.class_num + i, i] = 0
        return mask.bool()

    def forward(self, c_i, c_j):
        c_i = c_i.t()
        c_j = c_j.t()
        N = 2 * self.class_num
        c = torch.cat((c_i, c_j), dim=0)
        c = F.normalize(c, dim=1)

        sim = self.similarity_f(c.unsqueeze(1), c.unsqueeze(0)) / self.temperature
        sim_i_j = torch.diag(sim, self.class_num)
        sim_j_i = torch.diag(sim, -self.class_num)

        positive_clusters = torch.cat((sim_i_j, sim_j_i), dim=0).reshape(N, 1)
        negative_clusters = sim[self.mask].reshape(N, -1)

        labels = torch.zeros(N).to(positive_clusters.device).long()
        logits = torch.cat((positive_clusters, negative_clusters), dim=1)
        loss = self.criterion(logits, labels)

        return loss - torch.log(torch.tensor(self.class_num).float())


def getMILoss(P_H, P_C, prior, mi_estimator_hc, device):
    loss1 = 0
    loss2 = 0
    featureH = P_H.rsample()
    featureC = P_C
    featureX = prior.sample()
    loss2 += mi_estimator_hc(featureC, featureH)
    featureH = F.softmax(featureH, dim=-1)
    featureX = F.softmax(featureX, dim=-1)
    loss1 += torch.nn.functional.kl_div(featureH.log(), featureX, reduction='batchmean').to(device)
    return loss1, loss2


def MI_XH(h_distribution, x_distribution):
    kl_div = kl_divergence(h_distribution, x_distribution).sum(dim=1)
    mutual_information = kl_div.mean()
    return mutual_information


def MI_HC(h_feature, c_probability):
    h_probability = F.softmax(h_feature, dim=1)

    joint_prob = torch.matmul(c_probability.T, h_probability) / h_feature.size(0)

    p_t = h_probability.mean(dim=0, keepdim=True)
    p_c = c_probability.mean(dim=0, keepdim=True)

    log_joint = torch.log(joint_prob + 1e-9)
    log_marginal = torch.log(p_c.T @ p_t + 1e-9)
    log_ratio = log_joint - log_marginal

    mutual_information = torch.sum(joint_prob * log_ratio)

    return mutual_information



